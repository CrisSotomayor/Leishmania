#!/bin/bash

rsync -avzh diana@132.248.12.113:/home/diana/my_env/*.csv /home/diana/Leishmania/Resultados_11_03

rsync -avzh diana@132.248.12.113:/home/diana/my_env/*.png /home/diana/Leishmania/Resultados_11_03

rsync -avzh diana@132.248.12.113:/home/diana/my_env/log /home/diana/Leishmania/Resultados_11_03


